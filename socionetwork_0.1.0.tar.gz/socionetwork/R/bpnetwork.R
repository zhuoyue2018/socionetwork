
#' Introduce data concrete.csv
#' read the raw data
# concrete <- read.csv("C:/Users/PKUWHAI/Desktop/BPnetwork/concrete.csv")
# create data file
# usethis::use_data(concrete)
#' @importFrom Deriv Deriv
#' @importFrom ggplot2 ggplot aes geom_point theme_classic xlab
#' @importFrom neuralnet compute neuralnet
#* @useDynLib socionetwork
#* @import ggplot2
#* @import ggstatsplot
#* @importFrom magrittr %>%
#* @importFrom dplyr select
#* @export



#' Normalize a numeric vector
#'
#' This function takes a numeric vector as input and normalizes its elements to the range [0, 1].
#' Normalization is performed by subtracting the minimum value and dividing by the range (maximum value - minimum value).
#'
#' @param x A numeric vector to be normalized.
#' @return A normalized numeric vector with values in the range [0, 1].
#' @examples
#' x <- c(1, 2, 3, 4, 5)
#' normalize(x)
#' @export
normalize <- function(x){
  return((x - min(x)) / (max(x) - min(x)))
}


#' Preprocess and split a dataset into a training set
#'
#' This function takes a dataset as input, normalizes its numeric columns, and randomly selects a subset for the training set based on a specified ratio.
#'
#' @param data A data frame containing the dataset to be preprocessed and split.
#' @param ratio A numeric value (default: 0.9) representing the proportion of the dataset to be included in the training set.
#' @return A training set data frame with normalized numeric columns.
#' @examples
#' data <- data.frame(a = 1:5, b = c(2, 4, 6, 8, 10))
#' train <- pretreat.train(data, ratio = 0.8)
#' @export
pretreat.train <- function(data,ratio = 0.9){
  data <- as.data.frame(lapply(data, normalize))
  index <- sample(1:nrow(data),round((ratio)*nrow(data)))
  train <- data[index,]
  return(train)
}


#' Preprocess and split a dataset into a test set
#'
#' This function takes a dataset as input, normalizes its numeric columns, and randomly selects a subset for the test set based on a specified ratio.
#' The normalization is performed using the `normalize` function.
#'
#' @param data A data frame containing the dataset to be preprocessed and split.
#' @param ratio A numeric value (default: 0.1) representing the proportion of the dataset to be included in the test set.
#' @return A test set data frame with normalized numeric columns.
#' @examples
#' data <- data.frame(a = 1:5, b = c(2, 4, 6, 8, 10))
#' test <- pretreat.test(data, ratio = 0.2)
#' @export
pretreat.test <- function(data,ratio = 0.1){
  data <- as.data.frame(lapply(data, normalize))
  index <- sample(1:nrow(data),round((1 - ratio)*nrow(data)))
  test <- data[-index,]
  return(test)
}


#' Preprocess and split a dataset into training and test sets
#'
#' This function takes a dataset as input, normalizes its numeric columns, and randomly splits the dataset into training and test sets based on a specified ratio.
#' The normalization is performed using the `normalize` function. It also prints the summary of the original and normalized data.
#'
#' @param data A data frame containing the dataset to be preprocessed and split.
#' @param ratio A numeric value (default: 0.9) representing the proportion of the dataset to be included in the training set.
#' @return A list containing the test and training sets as data frames with normalized numeric columns.
#' @examples
#' data <- data.frame(a = 1:5, b = c(2, 4, 6, 8, 10))
#' sets <- pretreat(data, ratio = 0.8)
#' train <- sets[[2]]
#' test <- sets[[1]]
#' @keywords data
#' @export

pretreat <- function(data,ratio = 0.9){
  cat("Summary origin data infomation \n " )
  show(summary(data))
  data <- as.data.frame(lapply(data, normalize))
  cat("\n \n Summary normalized data infomation \n" )
  show(summary(data ))
  index <- sample(1:nrow(data),round(ratio*nrow(data)))
  train <- data[index,]
  test <- data[-index,]
  list(test,train)
}





#' Fitting the network
#' Show the network plot
#' Train a neural network model using the neuralnet package and plot the model structure
#'
#' This function trains a neural network model using the neuralnet package with the given arguments and plots the resulting model structure.
#' Please refer to the neuralnet package documentation for details on the input parameters.
#'
#' @param ... The arguments to be passed to the neuralnet::neuralnet function.
#' @return The plot of the neural network model structure.
#' @examples
#' library(neuralnet)
#' data <- data.frame(a = 1:5, b = c(2, 4, 6, 8, 10))
#' formula <- b ~ a
#' bpnet.plot(formula, data = data, hidden = 2, rep = 1)
#' @export
bpnet.plot <- function(...){
  model <- neuralnet::neuralnet(...)
  plot(model)
}

#' Fitting the network
#' Calculate the network plot
#' Train a neural network model and evaluate its performance
#'
#' This function trains a neural network model using the neuralnet package with the specified arguments, evaluates its performance on the test dataset, and plots the resulting model structure.
#' The function trains the neural network model repeatedly and evaluates the model performance based on the specified mean squared error (MSE) length.
#'
#' @param formula A symbolic description of the model to be fitted.
#' @param data.train A data frame containing the training data.
#' @param data.test A data frame containing the test data.
#' @param hidden The number of hidden neurons (default: 1).
#' @param threshold The threshold for the partial derivatives of the error function as stopping criteria (default: 0.01).
#' @param stepmax The maximum number of steps (default: 1e+05).
#' @param rep The number of repetitions for the neural network training (default: 1).
#' @param startweights Initial weights (default: NULL).
#' @param learningrate.limit The learning rate limits (default: NULL).
#' @param learningrate.factor A named list with elements "minus" and "plus" specifying the learning rate factors (default: list(minus = 0.5, plus = 1.2)).
#' @param learningrate The learning rate (default: NULL).
#' @param lifesign The output during training (default: "none").
#' @param lifesign.step The number of steps between lifesign output (default: 1000).
#' @param algorithm The learning algorithm to be used (default: "rprop+").
#' @param err.fct The error function to be used (default: "sse").
#' @param act.fct The activation function to be used (default: "logistic").
#' @param linear.output Whether the output is linear or not (default: TRUE).
#' @param exclude A vector of input variables to be excluded (default: NULL).
#' @param constant.weights Constant weights (default: NULL).
#' @param likelihood Whether to use maximum likelihood estimation (default: FALSE).
#' @param mse.length The length of MSE list used as a stopping criterion for the training process (default: 10).
#' @return A list containing the correlation, mean squared error list, netplot function, and predicted values.
#' @examples
#' data <- data.frame(a = 1:5, b = c(2, 4, 6, 8, 10))
#' formula <- b ~ a
#' train <- pretreat.train(data, ratio = 0.8)
#' test <- pretreat.test(data, ratio = 0.2)
#' result <- bpnet(formula, train, test, hidden = 2)
#' @export
bpnet <- function(formula, data.train, data.test, hidden = 1, threshold = 0.01, stepmax = 1e+05,
                  rep = 1, startweights = NULL, learningrate.limit = NULL,
                  learningrate.factor = list(minus = 0.5, plus = 1.2), learningrate = NULL,
                  lifesign = "none", lifesign.step = 1000, algorithm = "rprop+",
                  err.fct = "sse", act.fct = "logistic", linear.output = TRUE,
                  exclude = NULL, constant.weights = NULL, likelihood = FALSE, mse.length = 10){

  mse_list <- data.frame(MSE = numeric())
  repeat{
    model <- neuralnet(formula, data.train, data.test, hidden = 1, threshold = 0.01, stepmax = 1e+05,
                       rep = 1, startweights = NULL, learningrate.limit = NULL,
                       learningrate.factor = list(minus = 0.5, plus = 1.2), learningrate = NULL,
                       lifesign = "none", lifesign.step = 1000, algorithm = "rprop+",
                       err.fct = "sse", act.fct = "logistic", linear.output = TRUE,
                       exclude = NULL, constant.weights = NULL, likelihood = FALSE)
    model_results <- neuralnet::compute(model, data.test)
    predicted_y <- model_results$net.result
    dependent_var <- all.vars(formula)[1]
    corralation <- cor(predicted_y,data.test[[dependent_var]])
    mse <-  MSE_calculate(predicted_y,data.test[[dependent_var]])
    mse_list <- rbind(mse_list,mse)
    if (length(mse_list[[1]]) >= mse.length )
    {break}
  }
  if (length(dev.list()) > 0) dev.off()
  plot(model)
  show(corralation)
  netplot <- function (){plot(model)}
  colnames(mse_list)[1] <- "MSE"
  cat("Cor = ",corralation)
  cat("\n \n")
  cat("MSE = \n")
  print(mse_list)
  list(cor=corralation, mse.list=mse_list,netplot=netplot,predicted=predicted_y)

}


#' Calculate the Mean Squared Error (MSE) between true and predicted values
#'
#' This function computes the Mean Squared Error between two numeric vectors,
#' representing the true values and the predicted values.
#'
#' @param true_values A numeric vector of true values.
#' @param predicted_values A numeric vector of predicted values.
#' @return The Mean Squared Error (MSE) between true_values and predicted_values.
#' @examples
#' true_values <- c(1, 2, 3, 4, 5)
#' predicted_values <- c(1.1, 2.1, 3.1, 4.1, 5.1)
#' mse <- MSE_calculate(true_values, predicted_values)
#' @export
MSE_calculate <- function(true_values, predicted_values) {
  # Calculate the difference between true_values and predicted_values
  difference <- true_values - predicted_values

  # Square the differences
  squared_difference <- difference ^ 2

  # Calculate the mean of squared differences
  mse <- mean(squared_difference)

  # Return the Mean Squared Error (MSE)
  return(mse)
}



#' Draw a histogram with descriptive statistics using ggstatsplot
#'
#' This function creates a histogram with descriptive statistics using the ggstatsplot package with the specified arguments.
#' Please refer to the ggstatsplot package documentation for details on the input parameters.
#'
#' @param data A numeric vector or a data frame containing a single column of numeric data.
#' @return A ggplot object representing the histogram with descriptive statistics.
#' @examples
#' library(ggstatsplot)
#' data <- data.frame(a = rnorm(100))
#' hist_plot <- draw_histplot(data$a)
#' print(hist_plot)
#' @export

draw_histplot <- function(data) {
  if (is.data.frame(data) && ncol(data) == 1) {
    data <- data[[1]]
  }

  if (!is.numeric(data)) {
    stop("Input data must be a numeric vector or a data frame with a single numeric column.")
  }

  temp_df <- data.frame(x = data)
  plot <- ggstatsplot::gghistostats(data = temp_df, x = x)
  return(plot)
}




#' Draw a Customized Boxplot Using ggplot2
#' Draw a boxplot
#'
#' This function creates a boxplot using ggplot2.
#'
#' @param data The data frame containing the data to be plotted
#' @param x The variable to use on the x-axis
#' @param stat The statistical transformation to use; default is "boxplot"
#' @param ... Other arguments passed to geom_boxplot and stat_boxplot
#' @param fill The color of the box fill; default is "white"
#' @param outlier.colour The color of the outlier points; default is "red"
#' @param outlier.color Alternative spelling for outlier.colour
#' @param outlier.fill The fill color of the outlier points
#' @param outlier.shape The shape of the outlier points; default is 19
#' @param outlier.size The size of the outlier points; default is 1.5
#' @param outlier.stroke The stroke of the outlier points; default is 0.5
#' @param outlier.alpha The transparency of the outlier points
#' @param notch Logical, whether to display notched boxplots; default is FALSE
#' @param notchwidth The width of the notches; default is 0.5
#' @param varwidth Logical, whether to display variable-width boxplots; default is FALSE
#' @param orientation The orientation of the plot; default is NA
#' @param show.legend Logical, whether to show the legend; default is NA
#' @param inherit.aes Logical, whether to inherit aesthetics; default is TRUE
#' @param position The position adjustment; default is "dodge2"
#' @param coef The range of the whiskers; default is 1.5
#' @param na.rm Logical, whether to remove missing values; default is FALSE
#' @param geom The geom to use for displaying the boxplot; default is "boxplot"
#' @param plot_theme The theme for the plot; default is theme_classic()
#' @param flip_coords Logical, whether to flip the x and y coordinates; default is TRUE
#'
#' @return A ggplot2 boxplot
#' @examples
#' library(ggplot2)
#' data(iris)
#' draw_boxplot(iris, x = iris$Species, fill = "lightblue")
#' @export

draw_boxplot <- function(data, x,
                         stat = "boxplot",
                         fill = "white",
                         outlier.colour = "red",
                         outlier.color = NULL,
                         outlier.fill = NULL,
                         outlier.shape = 19,
                         outlier.size = 1.5,
                         outlier.stroke = 0.5,
                         outlier.alpha = NULL,
                         notch = FALSE,
                         notchwidth = 0.5,
                         varwidth = FALSE,
                         orientation = NA,
                         show.legend = NA,
                         inherit.aes = TRUE,
                         position = "dodge2",
                         coef = 1.5,
                         na.rm = FALSE,
                         geom = "boxplot",
                         plot_theme = theme_classic(),
                         flip_coords = TRUE) {

  plot <- ggplot(data, aes(x = x)) +
    geom_boxplot(
      stat =  stat,
      position = position,
      fill = fill,
      outlier.colour = outlier.colour,
      outlier.color = outlier.color,
      outlier.fill = outlier.fill,
      outlier.shape = outlier.shape,
      outlier.size = outlier.size,
      outlier.stroke = outlier.stroke,
      outlier.alpha = outlier.alpha,
      notch = notch,
      notchwidth = notchwidth,
      varwidth = varwidth,
      na.rm = na.rm,
      orientation = orientation,
      show.legend = show.legend,
      inherit.aes = inherit.aes
    ) +
    stat_boxplot(
      position = position,
      coef = coef,
      na.rm = na.rm,
      orientation = orientation,
      show.legend = show.legend,
      inherit.aes = inherit.aes,
      geom = geom) +
    plot_theme +
    xlab(x)

  if (flip_coords) {
    plot <- plot + coord_flip()
  }

  return(plot)
}


#' Extract histogram coordinates from a ggplot object
#'
#' This function takes a ggplot object representing a histogram as input and extracts the x and y coordinates. It also calculates the midpoint and maximum coordinates for the x and y axes.
#'
#' @param hist_plot A ggplot object representing a histogram.
#' @return A list containing the midpoint and maximum coordinates for the x and y axes (x_mid, y_mid, x_max, y_max).
#' @examples
#' library(ggplot2)
#' data <- data.frame(a = rnorm(100))
#' hist_plot <- ggplot(data, aes(x = a)) + geom_histogram()
#' histogram_coords <- get_histogram_coords(hist_plot)
#' @export
get_histogram_coords <- function(hist_plot) {
  # Calculates the details of a drawing object
  plot_data <- ggplot_build(hist_plot)

  # Get the x and y coordinates
  x_coords <- plot_data$data[[1]]$x
  y_coords <- plot_data$data[[1]]$y

  # Calculate the midpoint and maximum coordinates of the x and y axes
  x_mid <- mean(range(x_coords))
  y_mid <- mean(range(y_coords))
  x_max <- max(x_coords)
  y_max <- max(y_coords)

  # Returns a list with the required information
  return(list(x_mid = x_mid, y_mid = y_mid, x_max = x_max, y_max = y_max))
}


#' Combining previous plot and subplot
#' Combine a main plot with a subplot at specified coordinates
#'
#' This function takes a main ggplot object and a subplot ggplot object as input, and combines them using the specified coordinates. If any of the coordinates are not provided, the function will use default coordinates based on the main plot.
#'
#' @param plot A ggplot object representing the main plot.
#' @param subplot A ggplot object representing the subplot to be added to the main plot.
#' @param x_min The minimum x-coordinate for the subplot (default: midpoint of the x-axis of the main plot).
#' @param x_max The maximum x-coordinate for the subplot (default: maximum x-coordinate of the main plot).
#' @param y_min The minimum y-coordinate for the subplot (default: midpoint of the y-axis of the main plot).
#' @param y_max The maximum y-coordinate for the subplot (default: maximum y-coordinate of the main plot).
#' @return A ggplot object representing the combined main plot and subplot.
#' @examples
#' library(ggplot2)
#' library(ggstatsplot)
#' data <- data.frame(a = rnorm(100))
#' main_plot <- ggplot(data, aes(x = a)) + geom_histogram()
#' subplot <- ggstatsplot::gghistostats(data = data, x = a)
#' combined_plot <- draw_combined(main_plot, subplot, x_min = 2, x_max = 3, y_min = 5, y_max = 10)
#' @export
draw_combined <- function(plot,subplot,
                          x_min,x_max,
                          y_min,y_max){
  coords_info <- get_histogram_coords(plot)
  #Determine whether the four coordinates are non-existent
  #If one of them has no input, it is set as the default
  if (!x_min ){
    x_min <- coords_info$x_mid}
  if (!x_max ){
    x_max <- coords_info$x_max}
  if (!y_min ){
    y_min <- coords_info$y_mid}
  if (!y_max ){
    y_max <- coords_info$y_max}

  subplot <- ggplotGrob(subplot)
  result <- plot +annotation_custom(subplot,
                                    xmin= x_min,xmax=x_max,
                                    ymin=y_min,ymax=y_max)
  return(result)
}


#' Draw a histogram with descriptive statistics using ggstatsplot
#'
#' This function creates a histogram with descriptive statistics using the ggstatsplot package with the specified arguments.
#' Please refer to the ggstatsplot package documentation for details on the input parameters.
#'
#' @param data A data frame containing the variable for the histogram.
#' @param x_var A character string specifying the name of the column in the data frame to be used for the x aesthetic.
#' @param ... Additional arguments to be passed to the ggstatsplot::gghistostats function.
#' @examples
#' library(ggstatsplot)
#' library(ggplot2)
#' data <- data.frame(a = rnorm(100))
#' hist_plot <- draw_histplot(data, "a")
#' print(hist_plot)
#' @export

draw_histplot <- function(data, x_var, ...) {
  plot <- ggstatsplot::gghistostats(
    data = data,
    x = !!sym(x_var),
    ...
  )
  return(plot)
}









#' Thrid picture
#' Draw a point plot with a smoothed trend line
#'
#' This function creates a point plot with a smoothed trend line using ggplot2. It provides a convenient interface for ggplot2's geom_point and stat_smooth functions.
#' Please refer to the ggplot2 package documentation for details on the input parameters.
#'
#' @param mapping Set of aesthetic mappings created by `aes()` or `aes_()`. If specified and `inherit.aes = TRUE` (the default), it is combined with the default mapping at the top level of the plot. You must supply `mapping` if there is no plot mapping.
#' @param environment The environment in which to evaluate the plot.
#' @param data The data to be displayed in this layer.
#' @param stat The statistical transformation to use on the data for this layer, as a string.
#' @param geom The type of smoothing to be applied, as a string.
#' @param position Position adjustment, either as a string, or the result of a call to a position adjustment function.
#' @param ... Other arguments passed on to `layer()`. These are often aesthetics, used to set an aesthetic to a fixed value, like `color = "red"` or `size = 3`. They may also be parameters to the paired geom/stat.
#' @param na.rm If `FALSE`, the default, missing values are removed with a warning. If `TRUE`, missing values are silently removed.
#' @param method Smoothing method (function) to use, as a string.
#' @param show.legend Logical. Should this layer be included in the legends? `NA`, the default, includes if any aesthetics are mapped. `FALSE` never includes, and `TRUE` always includes.
#' @param inherit.aes If `FALSE`, overrides the default aesthetics, rather than combining with them. This is most useful for helper functions that define both data and aesthetics and shouldn't inherit behaviour from the default plot specification, e.g. `borders()`.
#' @param formula Formula to use in smoothing function, as a string.
#' @param se Display confidence interval around smooth? Default is `TRUE`.
#' @param n Number of points to evaluate smoother at.
#' @param span Controls the amount of smoothing for the default loess method. Larger values give more smoothing.
#' @param fullrange Should the fit span the full range of the plot, or just the data?
#' @param level Level of confidence interval to use (0.95 is the default).
#' @param method.args A list of additional arguments passed on to the method.
#' @param orientation The orientation of the smoothing line. This is typically not used.
#' @return A ggplot object representing the point plot with a smoothed trend line.
#' @examples
#' library(ggplot2)
#' data <- data.frame(x = rnorm(100), y = rnorm(100))
#' point_plot <- draw_pointplot(aes(x = x, y = y), data = data)
#' print(point_plot)
#' @export
draw_pointplot <- function(mapping = aes(),
                           environment = parent.frame(),
                           data = NULL,
                           stat = "identity",
                           geom = "smooth",
                           position = "identity",
                           ...,
                           na.rm = FALSE,
                           method = 'loess',
                           show.legend = NA,
                           inherit.aes = TRUE,
                           formula = NULL,
                           se = TRUE,
                           n = 80,
                           span = 0.75,
                           fullrange = FALSE,
                           level = 0.95,
                           method.args = list(),
                           orientation = NA){
  ggplot(data = data,
         mapping = mapping,
         ...,
         environment = environment )+
    geom_point(stat = stat,
               position = position,
               ...,
               na.rm = na.rm,
               show.legend = show.legend ,
               inherit.aes = inherit.aes)+
    stat_smooth(
      geom = geom ,
      position = position,
      ...,
      method = method ,
      formula = formula ,
      se = se,
      n =  n,
      span = span,
      fullrange = fullrange,
      level = level,
      method.args = method.args,
      na.rm = na.rm,
      orientation = orientation,
      show.legend = show.legend,
      inherit.aes = inherit.aes)

}




# Using neuralnet
##################################################
#' Fit a neural network model
#'
#' This function fits a feed-forward neural network model to the input data using a specified training algorithm.
neuralnet <-
  function (formula, data.train, data.test, hidden = 1, threshold = 0.01, stepmax = 1e+05,
            rep = 1, startweights = NULL, learningrate.limit = NULL,
            learningrate.factor = list(minus = 0.5, plus = 1.2), learningrate = NULL,
            lifesign = "none", lifesign.step = 1000, algorithm = "rprop+",
            err.fct = "sse", act.fct = "logistic", linear.output = TRUE,
            exclude = NULL, constant.weights = NULL, likelihood = FALSE) {

    # Save call
    call <- match.call()

    # Check arguments
    if (is.null(data.train)) {
      stop("Missing 'data.train' argument.", call. = FALSE)
    }
    data.train <- as.data.frame(data.train)

    if (is.null(formula)) {
      stop("Missing 'formula' argument.", call. = FALSE)
    }
    formula <- stats::as.formula(formula)

    # Learning rate limit
    if (!is.null(learningrate.limit)) {
      if (length(learningrate.limit) != 2) {
        stop("Argument 'learningrate.factor' must consist of two components.",
             call. = FALSE)
      }
      learningrate.limit <- as.list(learningrate.limit)
      names(learningrate.limit) <- c("min", "max")

      if (is.na(learningrate.limit$min) || is.na(learningrate.limit$max)) {
        stop("'learningrate.limit' must be a numeric vector",
             call. = FALSE)
      }
    } else {
      learningrate.limit <- list(min = 1e-10, max = 0.1)
    }

    # Learning rate factor
    if (!is.null(learningrate.factor)) {
      if (length(learningrate.factor) != 2) {
        stop("Argument 'learningrate.factor' must consist of two components.",
             call. = FALSE)
      }
      learningrate.factor <- as.list(learningrate.factor)
      names(learningrate.factor) <- c("minus", "plus")

      if (is.na(learningrate.factor$minus) || is.na(learningrate.factor$plus)) {
        stop("'learningrate.factor' must be a numeric vector",
             call. = FALSE)
      }
    } else {
      learningrate.factor <- list(minus = 0.5, plus = 1.2)
    }

    # Learning rate (backprop)
    if (algorithm == "backprop") {
      if (is.null(learningrate) || !is.numeric(learningrate)) {
        stop("Argument 'learningrate' must be a numeric value, if the backpropagation algorithm is used.",
             call. = FALSE)
      }
    }

    # TODO: Rename?
    # Lifesign
    if (!(lifesign %in% c("none", "minimal", "full"))) {
      stop("Argument 'lifesign' must be one of 'none', 'minimal', 'full'.", call. = FALSE)
    }

    # Algorithm
    if (!(algorithm %in% c("rprop+", "rprop-", "slr", "sag", "backprop"))) {
      stop("Unknown algorithm.", call. = FALSE)
    }

    # Threshold
    if (is.na(threshold)) {
      stop("Argument 'threshold' must be a numeric value.", call. = FALSE)
    }

    # Hidden units
    if (any(is.na(hidden))) {
      stop("Argument 'hidden' must be an integer vector or a single integer.",
           call. = FALSE)
    }
    if (length(hidden) > 1 && any(hidden == 0)) {
      stop("Argument 'hidden' contains at least one 0.", call. = FALSE)
    }

    # Replications
    if (is.na(rep)) {
      stop("Argument 'rep' must be an integer", call. = FALSE)
    }

    # Max steps
    if (is.na(stepmax)) {
      stop("Argument 'stepmax' must be an integer", call. = FALSE)
    }

    # Activation function
    if (!(is.function(act.fct) || act.fct %in% c("logistic", "tanh"))) {
      stop("Unknown activation function.", call. = FALSE)
    }

    # Error function
    if (!(is.function(err.fct) || err.fct %in% c("sse", "ce"))) {
      stop("Unknown error function.", call. = FALSE)
    }

    # Formula interface
    model.list <- list(response = attr(terms(as.formula(call("~", formula[[2]]))), "term.labels"),
                       variables = attr(terms(formula, data.train = data.train), "term.labels"))
    response <- as.matrix(model.frame(as.formula(call("~", formula[[2]])), data.train))
    covariate <- cbind(intercept = 1, as.matrix(data.train[, model.list$variables]))

    # Multiclass response
    if (is.character(response)) {
      class.names <- unique(response[, 1])
      response <- model.matrix( ~ response[,1]-1) == 1
      colnames(response) <- class.names
      model.list$response <- class.names
    }

    # Activation function
    if (is.function(act.fct)) {
      act.deriv.fct <- Deriv::Deriv(act.fct)
      attr(act.fct, "type") <- "function"
    } else {
      converted.fct <- convert.activation.function(act.fct)
      act.fct <- converted.fct$fct
      act.deriv.fct <- converted.fct$deriv.fct
    }

    # Error function
    if (is.function(err.fct)) {
      attr(err.fct, "type") <- "function"
      err.deriv.fct <- Deriv::Deriv(err.fct)
    } else {
      converted.fct <- convert.error.function(err.fct)
      err.fct <- converted.fct$fct
      err.deriv.fct <- converted.fct$deriv.fct
    }

    if (attr(err.fct, "type") == "ce" && !all(response %in% 0:1)) {
      stop("Error function 'ce' only implemented for binary response.", call. = FALSE)
    }

    # Fit network for each replication
    list.result <- lapply(1:rep, function(i) {
      # Show progress
      if (lifesign != "none") {
        lifesign <- display(hidden, threshold, rep, i, lifesign)
      }

      # Fit network
      calculate.neuralnet(learningrate.limit = learningrate.limit,
                          learningrate.factor = learningrate.factor, covariate = covariate,
                          response = response, data.train = data.train, model.list = model.list,
                          threshold = threshold, lifesign.step = lifesign.step,
                          stepmax = stepmax, hidden = hidden, lifesign = lifesign,
                          startweights = startweights, algorithm = algorithm,
                          err.fct = err.fct, err.deriv.fct = err.deriv.fct,
                          act.fct = act.fct, act.deriv.fct = act.deriv.fct,
                          rep = i, linear.output = linear.output, exclude = exclude,
                          constant.weights = constant.weights, likelihood = likelihood,
                          learningrate.bp = learningrate)
    })
    matrix <- sapply(list.result, function(x) {x$output.vector})
    if (all(sapply(matrix, is.null))) {
      list.result <- NULL
      matrix <- NULL
      ncol.matrix <- 0
    } else {
      ncol.matrix <- ncol(matrix)
    }

    # Warning if some replications did not converge
    if (ncol.matrix < rep) {
      warning(sprintf("Algorithm did not converge in %s of %s repetition(s) within the stepmax.",
                      (rep - ncol.matrix), rep), call. = FALSE)
    }

    # Return output
    generate.output(covariate, call, rep, threshold, matrix,
                    startweights, model.list, response, err.fct, act.fct,
                    data.train, list.result, linear.output, exclude)
  }

# Display output of replication

display <- function (hidden, threshold, rep, i.rep, lifesign) {
  message("hidden: ", paste(hidden, collapse = ", "), "    thresh: ",
          threshold, "    rep: ", strrep(" ", nchar(rep) - nchar(i.rep)),
          i.rep, "/", rep, "    steps: ", appendLF = FALSE)
  utils::flush.console()

  if (lifesign == "full") {
    lifesign <- sum(nchar(hidden)) + 2 * length(hidden) -
      2 + max(nchar(threshold)) + 2 * nchar(rep) + 41
  }
  return(lifesign)
}

# Generate output object

generate.output <- function(covariate, call, rep, threshold, matrix, startweights,
                            model.list, response, err.fct, act.fct, data.train, list.result,
                            linear.output, exclude) {

  nn <- list(call = call, response = response, covariate = covariate[, -1, drop = FALSE],
             model.list = model.list, err.fct = err.fct, act.fct = act.fct,
             linear.output = linear.output, data.train = data.train, exclude = exclude)

  if (!is.null(matrix)) {
    nn$net.result <- lapply(list.result, function(x) {x$net.result})
    nn$weights <- lapply(list.result, function(x) {x$weights})
    nn$generalized.weights <- lapply(list.result, function(x) {x$generalized.weights})
    nn$startweights <- lapply(list.result, function(x) {x$startweights})
    nn$result.matrix <- matrix
    rownames(nn$result.matrix) <- c(rownames(matrix)[rownames(matrix) != ""],
                                    get_weight_names(nn$weights[[1]], model.list))
  }

  class(nn) <- c("nn")
  return(nn)
}

# Get names of all weights in network

get_weight_names <- function(weights, model.list) {
  # All hidden unit names
  if (length(weights) > 1) {
    hidden_units <- lapply(1:(length(weights) - 1), function(i) {
      paste0(i, "layhid", 1:ncol(weights[[i]]))
    })
  } else {
    hidden_units <- list()
  }

  # All unit names including input and output
  units <- c(list(model.list$variables),
             hidden_units,
             list(model.list$response))

  # Combine each layer with the next, add intercept
  weight_names <- do.call(c, lapply(1:(length(units) - 1), function(i) {
    as.vector(outer(c("Intercept", units[[i]]), units[[i + 1]], paste, sep = ".to."))
  }))
  return(weight_names)
}



# Convert named activation functions in R functions, including derivatives

convert.activation.function <- function(fun) {
  if (fun == "tanh") {
    fct <- function(x) {
      tanh(x)
    }
    attr(fct, "type") <- "tanh"
    deriv.fct <- function(x) {
      1 - x^2
    }
  } else if (fun == "logistic") {
    fct <- function(x) {
      1/(1 + exp(-x))
    }
    attr(fct, "type") <- "logistic"
    deriv.fct <- function(x) {
      x * (1 - x)
    }
  } else {
    stop("Unknown function.", call. = FALSE)
  }
  list(fct = fct, deriv.fct = deriv.fct)
}

# Convert named error functions in R functions, including derivatives

convert.error.function <- function(fun) {
  if (fun == "sse") {
    fct <- function(x, y) {
      1/2 * (y - x)^2
    }
    attr(fct, "type") <- "sse"
    deriv.fct <- function(x, y) {
      x - y
    }
  } else if (fun == "ce") {
    fct <- function(x, y) {
      -(y * log(x) + (1 - y) * log(1 - x))
    }
    attr(fct, "type") <- "ce"
    deriv.fct <- function(x, y) {
      (1 - y)/(1 - x) - y/x
    }
  } else {
    stop("Unknown function.", call. = FALSE)
  }
  list(fct = fct, deriv.fct = deriv.fct)
}

calculate.neuralnet <-
  function (data.train, model.list, hidden, stepmax, rep, threshold,
            learningrate.limit, learningrate.factor, lifesign, covariate,
            response, lifesign.step, startweights, algorithm, act.fct,
            act.deriv.fct, err.fct, err.deriv.fct, linear.output, likelihood,
            exclude, constant.weights, learningrate.bp)
  {
    time.start.local <- Sys.time()
    result <- generate.startweights(model.list, hidden, startweights,
                                    rep, exclude, constant.weights)
    weights <- result$weights
    exclude <- result$exclude
    nrow.weights <- sapply(weights, nrow)
    ncol.weights <- sapply(weights, ncol)
    result <- rprop(weights = weights, threshold = threshold,
                    response = response, covariate = covariate, learningrate.limit = learningrate.limit,
                    learningrate.factor = learningrate.factor, stepmax = stepmax,
                    lifesign = lifesign, lifesign.step = lifesign.step, act.fct = act.fct,
                    act.deriv.fct = act.deriv.fct, err.fct = err.fct, err.deriv.fct = err.deriv.fct,
                    algorithm = algorithm, linear.output = linear.output,
                    exclude = exclude, learningrate.bp = learningrate.bp)
    startweights <- weights
    weights <- result$weights
    step <- result$step
    reached.threshold <- result$reached.threshold
    net.result <- result$net.result
    error <- sum(err.fct(net.result, response))
    if (is.na(error) & attr(err.fct, "type") == "ce")
      if (all(net.result <= 1, net.result >= 0))
        error <- sum(err.fct(net.result, response), na.rm = T)
    if (!is.null(constant.weights) && any(constant.weights !=
                                          0))
      exclude <- exclude[-which(constant.weights != 0)]
    if (length(exclude) == 0)
      exclude <- NULL
    aic <- NULL
    bic <- NULL
    if (likelihood) {
      synapse.count <- length(unlist(weights)) - length(exclude)
      aic <- 2 * error + (2 * synapse.count)
      bic <- 2 * error + log(nrow(response)) * synapse.count
    }
    if (is.na(error))
      warning("'err.fct' does not fit 'data.train' or 'act.fct'",
              call. = F)
    if (lifesign != "none") {
      if (reached.threshold <= threshold) {
        message(rep(" ", (max(nchar(stepmax), nchar("stepmax")) -
                            nchar(step))), step, appendLF = FALSE)
        message("\terror: ", round(error, 5), rep(" ", 6 - (nchar(round(error,
                                                                        5)) - nchar(round(error, 0)))), appendLF = FALSE)
        if (!is.null(aic)) {
          message("\taic: ", round(aic, 5), rep(" ", 6 - (nchar(round(aic,
                                                                      5)) - nchar(round(aic, 0)))), appendLF = FALSE)
        }
        if (!is.null(bic)) {
          message("\tbic: ", round(bic, 5), rep(" ", 6 - (nchar(round(bic,
                                                                      5)) - nchar(round(bic, 0)))), appendLF = FALSE)
        }
        time <- difftime(Sys.time(), time.start.local)
        message("\ttime: ", round(time, 2), " ", attr(time, "units"))
      }
    }
    if (reached.threshold > threshold)
      return(result = list(output.vector = NULL, weights = NULL))
    output.vector <- c(error = error, reached.threshold = reached.threshold,
                       steps = step)
    if (!is.null(aic)) {
      output.vector <- c(output.vector, aic = aic)
    }
    if (!is.null(bic)) {
      output.vector <- c(output.vector, bic = bic)
    }
    for (w in 1:length(weights)) output.vector <- c(output.vector,
                                                    as.vector(weights[[w]]))
    generalized.weights <- calculate.generalized.weights(weights,
                                                         neuron.deriv = result$neuron.deriv, net.result = net.result)
    startweights <- unlist(startweights)
    weights <- unlist(weights)
    if (!is.null(exclude)) {
      startweights[exclude] <- NA
      weights[exclude] <- NA
    }
    startweights <- relist(startweights, nrow.weights, ncol.weights)
    weights <- relist(weights, nrow.weights, ncol.weights)
    return(list(generalized.weights = generalized.weights, weights = weights,
                startweights = startweights, net.result = result$net.result,
                output.vector = output.vector))
  }
generate.startweights <-
  function (model.list, hidden, startweights, rep, exclude, constant.weights)
  {
    input.count <- length(model.list$variables)
    output.count <- length(model.list$response)
    if (!(length(hidden) == 1 && hidden == 0)) {
      length.weights <- length(hidden) + 1
      nrow.weights <- array(0, dim = c(length.weights))
      ncol.weights <- array(0, dim = c(length.weights))
      nrow.weights[1] <- (input.count + 1)
      ncol.weights[1] <- hidden[1]
      if (length(hidden) > 1)
        for (i in 2:length(hidden)) {
          nrow.weights[i] <- hidden[i - 1] + 1
          ncol.weights[i] <- hidden[i]
        }
      nrow.weights[length.weights] <- hidden[length.weights -
                                               1] + 1
      ncol.weights[length.weights] <- output.count
    }
    else {
      length.weights <- 1
      nrow.weights <- array((input.count + 1), dim = c(1))
      ncol.weights <- array(output.count, dim = c(1))
    }
    length <- sum(ncol.weights * nrow.weights)
    vector <- rep(0, length)
    if (!is.null(exclude)) {
      if (is.matrix(exclude)) {
        exclude <- matrix(as.integer(exclude), ncol = ncol(exclude),
                          nrow = nrow(exclude))
        if (nrow(exclude) >= length || ncol(exclude) != 3)
          stop("'exclude' has wrong dimensions", call. = FALSE)
        if (any(exclude < 1))
          stop("'exclude' contains at least one invalid weight",
               call. = FALSE)
        temp <- relist(vector, nrow.weights, ncol.weights)
        for (i in 1:nrow(exclude)) {
          if (exclude[i, 1] > length.weights || exclude[i,
                                                        2] > nrow.weights[exclude[i, 1]] || exclude[i,
                                                                                                    3] > ncol.weights[exclude[i, 1]])
            stop("'exclude' contains at least one invalid weight",
                 call. = FALSE)
          temp[[exclude[i, 1]]][exclude[i, 2], exclude[i,
                                                       3]] <- 1
        }
        exclude <- which(unlist(temp) == 1)
      }
      else if (is.vector(exclude)) {
        exclude <- as.integer(exclude)
        if (max(exclude) > length || min(exclude) < 1) {
          stop("'exclude' contains at least one invalid weight",
               call. = FALSE)
        }
      }
      else {
        stop("'exclude' must be a vector or matrix", call. = FALSE)
      }
      if (length(exclude) >= length)
        stop("all weights are exluded", call. = FALSE)
    }
    length <- length - length(exclude)
    if (!is.null(exclude)) {
      if (is.null(startweights) || length(startweights) < (length *
                                                           rep))
        vector[-exclude] <- stats::rnorm(length)
      else vector[-exclude] <- startweights[((rep - 1) * length +
                                               1):(length * rep)]
    }
    else {
      if (is.null(startweights) || length(startweights) < (length *
                                                           rep))
        vector <- stats::rnorm(length)
      else vector <- startweights[((rep - 1) * length + 1):(length *
                                                              rep)]
    }
    if (!is.null(exclude) && !is.null(constant.weights)) {
      if (length(exclude) < length(constant.weights))
        stop("constant.weights contains more weights than exclude",
             call. = FALSE)
      else vector[exclude[1:length(constant.weights)]] <- constant.weights
    }
    weights <- relist(vector, nrow.weights, ncol.weights)
    return(list(weights = weights, exclude = exclude))
  }
rprop <-
  function (weights, response, covariate, threshold, learningrate.limit,
            learningrate.factor, stepmax, lifesign, lifesign.step, act.fct,
            act.deriv.fct, err.fct, err.deriv.fct, algorithm, linear.output,
            exclude, learningrate.bp)
  {
    step <- 1
    nchar.stepmax <- max(nchar(stepmax), 7)
    length.weights <- length(weights)
    nrow.weights <- sapply(weights, nrow)
    ncol.weights <- sapply(weights, ncol)
    length.unlist <- length(unlist(weights)) - length(exclude)
    learningrate <- as.vector(matrix(0.1, nrow = 1, ncol = length.unlist))
    gradients.old <- as.vector(matrix(0, nrow = 1, ncol = length.unlist))
    if (is.null(exclude))
      exclude <- length(unlist(weights)) + 1
    if (attr(act.fct, "type") == "tanh" || attr(act.fct, "type") == "logistic")
      special <- TRUE
    else special <- FALSE
    if (linear.output) {
      output.act.fct <- function(x) {
        x
      }
      output.act.deriv.fct <- function(x) {
        matrix(1, nrow(x), ncol(x))
      }
    }
    else {
      if (attr(err.fct, "type") == "ce" && attr(act.fct, "type") == "logistic") {
        err.deriv.fct <- function(x, y) {
          x * (1 - y) - y * (1 - x)
        }
        linear.output <- TRUE
      }
      output.act.fct <- act.fct
      output.act.deriv.fct <- act.deriv.fct
    }
    result <- compute.net(weights, length.weights, covariate = covariate,
                          act.fct = act.fct, act.deriv.fct = act.deriv.fct, output.act.fct = output.act.fct,
                          output.act.deriv.fct = output.act.deriv.fct, special)
    err.deriv <- err.deriv.fct(result$net.result, response)
    gradients <- calculate.gradients(weights = weights, length.weights = length.weights,
                                     neurons = result$neurons, neuron.deriv = result$neuron.deriv,
                                     err.deriv = err.deriv, exclude = exclude, linear.output = linear.output)
    reached.threshold <- max(abs(gradients))
    min.reached.threshold <- reached.threshold
    while (step < stepmax && reached.threshold > threshold) {
      if (!is.character(lifesign) && step%%lifesign.step ==
          0) {
        text <- paste("%", nchar.stepmax, "s", sep = "")
        message(sprintf(eval(expression(text)), step), "\tmin thresh: ",
                min.reached.threshold, "\n", rep(" ", lifesign), appendLF = FALSE)
        utils::flush.console()
      }
      if (algorithm == "rprop+")
        result <- plus(gradients, gradients.old, weights,
                       nrow.weights, ncol.weights, learningrate, learningrate.factor,
                       learningrate.limit, exclude)
      else if (algorithm == "backprop")
        result <- backprop(gradients, weights, length.weights,
                           nrow.weights, ncol.weights, learningrate.bp,
                           exclude)
      else result <- minus(gradients, gradients.old, weights,
                           length.weights, nrow.weights, ncol.weights, learningrate,
                           learningrate.factor, learningrate.limit, algorithm,
                           exclude)
      gradients.old <- result$gradients.old
      weights <- result$weights
      learningrate <- result$learningrate
      result <- compute.net(weights, length.weights, covariate = covariate,
                            act.fct = act.fct, act.deriv.fct = act.deriv.fct,
                            output.act.fct = output.act.fct, output.act.deriv.fct = output.act.deriv.fct,
                            special)
      err.deriv <- err.deriv.fct(result$net.result, response)
      gradients <- calculate.gradients(weights = weights, length.weights = length.weights,
                                       neurons = result$neurons, neuron.deriv = result$neuron.deriv,
                                       err.deriv = err.deriv, exclude = exclude, linear.output = linear.output)
      reached.threshold <- max(abs(gradients))
      if (reached.threshold < min.reached.threshold) {
        min.reached.threshold <- reached.threshold
      }
      step <- step + 1
    }
    if (lifesign != "none" && reached.threshold > threshold) {
      message("stepmax\tmin thresh: ", min.reached.threshold)
    }
    return(list(weights = weights, step = as.integer(step), reached.threshold = reached.threshold,
                net.result = result$net.result, neuron.deriv = result$neuron.deriv))
  }





compute.net <-
  function (weights, length.weights, covariate, act.fct, act.deriv.fct,
            output.act.fct, output.act.deriv.fct, special)
  {
    neuron.deriv <- NULL
    neurons <- list(covariate)
    if (length.weights > 1)
      for (i in 1:(length.weights - 1)) {
        temp <- neurons[[i]] %*% weights[[i]]
        act.temp <- act.fct(temp)
        if (special)
          neuron.deriv[[i]] <- act.deriv.fct(act.temp)
        else neuron.deriv[[i]] <- act.deriv.fct(temp)
        neurons[[i + 1]] <- cbind(1, act.temp)
      }
    if (!is.list(neuron.deriv))
      neuron.deriv <- list(neuron.deriv)
    temp <- neurons[[length.weights]] %*% weights[[length.weights]]
    net.result <- output.act.fct(temp)
    if (special)
      neuron.deriv[[length.weights]] <- output.act.deriv.fct(net.result)
    else neuron.deriv[[length.weights]] <- output.act.deriv.fct(temp)
    if (any(is.na(neuron.deriv)))
      stop("neuron derivatives contain a NA; varify that the derivative function does not divide by 0",
           call. = FALSE)
    list(neurons = neurons, neuron.deriv = neuron.deriv, net.result = net.result)
  }


calculate.gradients <-
  function (weights, length.weights, neurons, neuron.deriv, err.deriv,
            exclude, linear.output)
  {
    if (any(is.na(err.deriv)))
      stop("the error derivative contains a NA; varify that the derivative function does not divide by 0 (e.g. cross entropy)",
           call. = FALSE)
    if (!linear.output)
      delta <- neuron.deriv[[length.weights]] * err.deriv
    else delta <- err.deriv
    gradients <- crossprod(neurons[[length.weights]], delta)
    if (length.weights > 1)
      for (w in (length.weights - 1):1) {
        delta <- neuron.deriv[[w]] * tcrossprod(delta, weights[[w + 1]][-1,, drop = FALSE])
        gradients <- c(crossprod(neurons[[w]], delta), gradients)
      }
    gradients[-exclude]
  }

plus <-
  function (gradients, gradients.old, weights, nrow.weights, ncol.weights,
            learningrate, learningrate.factor, learningrate.limit, exclude)
  {
    weights <- unlist(weights)
    sign.gradient <- sign(gradients)
    temp <- gradients.old * sign.gradient
    positive <- temp > 0
    negative <- temp < 0
    not.negative <- !negative
    if (any(positive)) {
      learningrate[positive] <- pmin.int(learningrate[positive] *
                                           learningrate.factor$plus, learningrate.limit$max)
    }
    if (any(negative)) {
      weights[-exclude][negative] <- weights[-exclude][negative] +
        gradients.old[negative] * learningrate[negative]
      learningrate[negative] <- pmax.int(learningrate[negative] *
                                           learningrate.factor$minus, learningrate.limit$min)
      gradients.old[negative] <- 0
      if (any(not.negative)) {
        weights[-exclude][not.negative] <- weights[-exclude][not.negative] -
          sign.gradient[not.negative] * learningrate[not.negative]
        gradients.old[not.negative] <- sign.gradient[not.negative]
      }
    }
    else {
      weights[-exclude] <- weights[-exclude] - sign.gradient *
        learningrate
      gradients.old <- sign.gradient
    }
    list(gradients.old = gradients.old, weights = relist(weights,
                                                         nrow.weights, ncol.weights), learningrate = learningrate)
  }
backprop <-
  function (gradients, weights, length.weights, nrow.weights, ncol.weights,
            learningrate.bp, exclude)
  {
    weights <- unlist(weights)
    if (!is.null(exclude))
      weights[-exclude] <- weights[-exclude] - gradients *
        learningrate.bp
    else weights <- weights - gradients * learningrate.bp
    list(gradients.old = gradients, weights = relist(weights,
                                                     nrow.weights, ncol.weights), learningrate = learningrate.bp)
  }
minus <-
  function (gradients, gradients.old, weights, length.weights,
            nrow.weights, ncol.weights, learningrate, learningrate.factor,
            learningrate.limit, algorithm, exclude)
  {
    weights <- unlist(weights)
    temp <- gradients.old * gradients
    positive <- temp > 0
    negative <- temp < 0
    if (any(positive))
      learningrate[positive] <- pmin.int(learningrate[positive] *
                                           learningrate.factor$plus, learningrate.limit$max)
    if (any(negative))
      learningrate[negative] <- pmax.int(learningrate[negative] *
                                           learningrate.factor$minus, learningrate.limit$min)
    if (algorithm != "rprop-") {
      delta <- 10^-6
      notzero <- gradients != 0
      gradients.notzero <- gradients[notzero]
      if (algorithm == "slr") {
        min <- which.min(learningrate[notzero])
      }
      else if (algorithm == "sag") {
        min <- which.min(abs(gradients.notzero))
      }
      if (length(min) != 0) {
        temp <- learningrate[notzero] * gradients.notzero
        sum <- sum(temp[-min]) + delta
        learningrate[notzero][min] <- min(max(-sum/gradients.notzero[min],
                                              learningrate.limit$min), learningrate.limit$max)
      }
    }
    weights[-exclude] <- weights[-exclude] - sign(gradients) *
      learningrate
    list(gradients.old = gradients, weights = relist(weights,
                                                     nrow.weights, ncol.weights), learningrate = learningrate)
  }
calculate.generalized.weights <-
  function (weights, neuron.deriv, net.result)
  {
    for (w in 1:length(weights)) {
      weights[[w]] <- weights[[w]][-1,, drop = FALSE]
    }
    generalized.weights <- NULL
    for (k in 1:ncol(net.result)) {
      for (w in length(weights):1) {
        if (w == length(weights)) {
          temp <- neuron.deriv[[length(weights)]][, k] *
            1/(net.result[, k] * (1 - (net.result[, k])))
          delta <- tcrossprod(temp, weights[[w]][, k])
        }
        else {
          delta <- tcrossprod(delta * neuron.deriv[[w]],
                              weights[[w]])
        }
      }
      generalized.weights <- cbind(generalized.weights, delta)
    }
    return(generalized.weights)
  }

relist <-
  function (x, nrow, ncol)
  {
    list.x <- NULL
    for (w in 1:length(nrow)) {
      length <- nrow[w] * ncol[w]
      list.x[[w]] <- matrix(x[1:length], nrow = nrow[w], ncol = ncol[w])
      x <- x[-(1:length)]
    }
    list.x
  }


