# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.
#
# Where should you do additional test configuration?
# Learn more about the roles of various files in:
# * https://r-pkgs.org/tests.html
# * https://testthat.r-lib.org/reference/test_package.html#special-files

library(testthat)
library(socionetwork)


library(testthat)

test_that("pretreat function works as expected", {
  # Generate example data
  data <- data.frame(a = rnorm(100), b = rnorm(100), c = rnorm(100))

  # Run the pretreat function with a given ratio
  ratio <- 0.8
  result <- pretreat(data, ratio)

  # Check that the output is a list with two elements
  expect_true(is.list(result))
  expect_equal(length(result), 2)

  # Check that the train and test data are data frames
  expect_true(is.data.frame(result[[1]]))
  expect_true(is.data.frame(result[[2]]))

  # Check that the train and test data have the correct number of rows
  expected_train_rows <- round(ratio * nrow(data))
  expected_test_rows <- nrow(data) - expected_train_rows
  expect_equal(nrow(result[[1]]), expected_test_rows)
  expect_equal(nrow(result[[2]]), expected_train_rows)

  # Check that the train and test data have the same number of columns as the input data
  expect_equal(ncol(result[[1]]), ncol(data))
  expect_equal(ncol(result[[2]]), ncol(data))
})
